const input = document.getElementById("contract-file");
const zone = document.getElementById("dropzone");
const label = document.getElementById("file-label");
const hint = document.getElementById("file-hint");
if (input && zone) {
  input.addEventListener("change", () => {
    if (input.files && input.files[0]) {
      label.textContent = input.files[0].name;
      hint.textContent = `${(input.files[0].size / 1024 / 1024).toFixed(2)} MB · Ready to analyze`;
      zone.classList.add("selected");
    }
  });
  ["dragenter", "dragover"].forEach(eventName => zone.addEventListener(eventName, e => {
    e.preventDefault(); zone.classList.add("dragging");
  }));
  ["dragleave", "drop"].forEach(eventName => zone.addEventListener(eventName, e => {
    e.preventDefault(); zone.classList.remove("dragging");
  }));
  zone.addEventListener("drop", e => {
    if (e.dataTransfer.files.length) {
      input.files = e.dataTransfer.files;
      input.dispatchEvent(new Event("change"));
    }
  });
}
